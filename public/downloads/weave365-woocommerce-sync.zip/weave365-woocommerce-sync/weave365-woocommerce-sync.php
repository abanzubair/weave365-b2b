<?php
/**
 * Plugin Name: Weave365 Live Stock Sync for WooCommerce
 * Plugin URI: https://www.weave365.com/developer-api
 * Description: Automated real-time stock synchronization, checkout stock guard, and optional automated order fulfillment for WooCommerce stores connected to Weave365 B2B.
 * Version: 1.2.0
 * Author: Weave365
 * Author URI: https://www.weave365.com
 * Requires at least: 5.6
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 * Requires Plugins: woocommerce
 * License: GPL-2.0-or-later
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

if (!defined('WEAVE365_WC_SYNC_VERSION')) {
    define('WEAVE365_WC_SYNC_VERSION', '1.2.0');
}

// Declare WooCommerce High-Performance Order Storage (HPOS) compatibility
add_action('before_woocommerce_init', function () {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
    }
});

class Weave365_WooCommerce_Sync {

    const VERSION = '1.2.0';
    const API_BASE_URL = 'https://www.weave365.com/api/v1';

    // Core stock sync options & hooks
    const OPTION_API_KEY = 'weave365_api_key';
    const OPTION_LAST_SYNC_TIME = 'weave365_last_sync_time';
    const OPTION_LAST_SYNC_STATUS = 'weave365_last_sync_status';
    const CRON_HOOK = 'weave365_cron_stock_sync';
    const TRANSIENT_LOCK = 'weave365_sync_lock';

    // Entitlement & capability options/transients (v1.2.0)
    const OPTION_ORDERS_API_ALLOWED = 'weave365_orders_api_allowed';
    const OPTION_ACCOUNT_TIER = 'weave365_account_tier';
    const OPTION_CLIENT_NAME = 'weave365_client_name';
    const OPTION_REMAINING_QUOTA = 'weave365_remaining_quota';
    const TRANSIENT_CAPABILITIES_CHECKED = 'weave365_capabilities_checked';

    // Order fulfillment settings (v1.2.0, unlocked only when orders_enabled === true)
    const OPTION_AUTO_FORWARD_ORDERS = 'weave365_auto_forward_orders';
    const OPTION_FORWARD_COD_ORDERS = 'weave365_forward_cod_orders';
    const OPTION_SENDER_NAME = 'weave365_sender_name';
    const OPTION_SENDER_PHONE = 'weave365_sender_phone';
    const OPTION_PACKING_PREFERENCE = 'weave365_packing_preference';
    const DEFAULT_PACKING_PREFERENCE = 'Standard Protective Wholesale Packaging';

    public function __construct() {
        // Admin menu & settings
        add_action('admin_menu', [$this, 'register_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_init', [$this, 'check_cron_schedule_fallback']);

        // Immediately re-verify capabilities whenever API key is saved or changed
        add_action('update_option_' . self::OPTION_API_KEY, [$this, 'handle_api_key_changed'], 10, 3);
        add_action('add_option_' . self::OPTION_API_KEY, [$this, 'handle_api_key_added'], 10, 2);

        // Scheduled cron execution
        add_action(self::CRON_HOOK, [$this, 'execute_stock_sync']);

        // Manual actions via admin-post.php (Post-Redirect-Get pattern)
        add_action('admin_post_weave365_manual_sync', [$this, 'handle_manual_sync']);
        add_action('admin_post_weave365_refresh_capabilities', [$this, 'handle_refresh_capabilities']);

        // Mandatory Real-Time Pre-Checkout Stock Verification Guard (Classic Checkout)
        add_action('woocommerce_check_cart_items', [$this, 'validate_cart_stock_live']);
        add_action('woocommerce_checkout_process', [$this, 'validate_cart_stock_live']);

        // WooCommerce Blocks (Store API) Checkout Guard
        add_action('woocommerce_store_api_cart_errors', [$this, 'validate_store_api_cart_stock'], 10, 2);
        add_action('woocommerce_store_api_checkout_update_order_from_request', [$this, 'validate_store_api_checkout_stock'], 10, 2);

        // Plugin action links
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), [$this, 'add_plugin_action_links']);

        // Strict Order API hook gating: register zero order hooks if entitlement is not verified
        if ($this->is_order_api_allowed()) {
            // Manual Send / Retry Order Action & HPOS-compatible Order Status Meta Box
            add_filter('woocommerce_order_actions', [$this, 'register_manual_order_action'], 10, 2);
            add_action('woocommerce_order_action_weave365_send_order', [$this, 'handle_manual_order_action'], 10, 1);
            add_action('add_meta_boxes', [$this, 'register_order_status_meta_box']);

            // Automated order forwarding hooks (only when merchant explicitly opts in)
            if (get_option(self::OPTION_AUTO_FORWARD_ORDERS, '0') === '1') {
                add_action('woocommerce_payment_complete', [$this, 'handle_auto_forward_order'], 20, 1);
                add_action('woocommerce_order_status_processing', [$this, 'handle_auto_forward_order'], 20, 2);

                if (get_option(self::OPTION_FORWARD_COD_ORDERS, '0') === '1') {
                    add_action('woocommerce_order_status_on-hold', [$this, 'handle_auto_forward_cod_on_hold'], 20, 2);
                }
            }
        }
    }

    /**
     * Check whether the connected API key has verified Order API entitlement.
     *
     * @return bool
     */
    public function is_order_api_allowed() {
        $api_key = trim((string) get_option(self::OPTION_API_KEY, ''));
        if ($api_key === '') {
            return false;
        }
        return get_option(self::OPTION_ORDERS_API_ALLOWED, '0') === '1';
    }

    /**
     * Activation callback: schedule cron (interval filterable).
     */
    public static function plugin_activated() {
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            $interval = apply_filters('weave365_sync_interval', 'hourly');
            wp_schedule_event(time(), $interval, self::CRON_HOOK);
        }
    }

    /**
     * Deactivation callback: clear cron and release locks/capability cache.
     */
    public static function plugin_deactivated() {
        wp_clear_scheduled_hook(self::CRON_HOOK);
        delete_transient(self::TRANSIENT_LOCK);
        delete_transient(self::TRANSIENT_CAPABILITIES_CHECKED);
    }

    /**
     * Fallback to ensure cron is scheduled if plugin was updated without re-activation.
     */
    public function check_cron_schedule_fallback() {
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            $interval = apply_filters('weave365_sync_interval', 'hourly');
            wp_schedule_event(time(), $interval, self::CRON_HOOK);
        }
    }

    /**
     * Admin notice when WooCommerce is inactive.
     */
    public static function woocommerce_missing_notice() {
        if (!current_user_can('activate_plugins')) {
            return;
        }
        ?>
        <div class="notice notice-error is-dismissible">
            <p><strong>Weave365 Live Stock Sync</strong> requires <strong>WooCommerce</strong> to be installed and active. Please activate WooCommerce to enable stock synchronization.</p>
        </div>
        <?php
    }

    public function add_plugin_action_links($links) {
        $settings_link = '<a href="' . esc_url(admin_url('admin.php?page=weave365-sync')) . '">Settings</a>';
        array_unshift($links, $settings_link);
        return $links;
    }

    public function register_admin_menu() {
        add_submenu_page(
            'woocommerce',
            'Weave365 Stock & Order Sync',
            'Weave365 Sync',
            'manage_woocommerce',
            'weave365-sync',
            [$this, 'render_settings_page']
        );
    }

    /**
     * Supported wholesale packing preference options.
     *
     * @return array
     */
    private function get_packing_preferences() {
        return [
            self::DEFAULT_PACKING_PREFERENCE,
            'Neutral Unbranded Reseller Packaging',
            'Gift-Ready Premium Box Packaging',
            'Minimal Eco-Friendly Kraft Packaging',
            'Double-Layer Moisture-Proof Export Wrap',
            'Branded Store Insert Ready',
        ];
    }

    public function register_settings() {
        register_setting('weave365_settings_group', self::OPTION_API_KEY, [
            'type'              => 'string',
            'sanitize_callback' => [$this, 'sanitize_api_key'],
            'default'           => '',
            'autoload'          => false,
        ]);

        register_setting('weave365_order_settings_group', self::OPTION_AUTO_FORWARD_ORDERS, [
            'type'              => 'string',
            'sanitize_callback' => [$this, 'sanitize_auto_forward_orders'],
            'default'           => '0',
            'autoload'          => false,
        ]);

        register_setting('weave365_order_settings_group', self::OPTION_FORWARD_COD_ORDERS, [
            'type'              => 'string',
            'sanitize_callback' => [$this, 'sanitize_forward_cod_orders'],
            'default'           => '0',
            'autoload'          => false,
        ]);

        register_setting('weave365_order_settings_group', self::OPTION_SENDER_NAME, [
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => '',
            'autoload'          => false,
        ]);

        register_setting('weave365_order_settings_group', self::OPTION_SENDER_PHONE, [
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => '',
            'autoload'          => false,
        ]);

        register_setting('weave365_order_settings_group', self::OPTION_PACKING_PREFERENCE, [
            'type'              => 'string',
            'sanitize_callback' => [$this, 'sanitize_packing_preference'],
            'default'           => self::DEFAULT_PACKING_PREFERENCE,
            'autoload'          => false,
        ]);
    }

    public function sanitize_api_key($value) {
        $value = sanitize_text_field(trim((string) $value));
        if (strpos($value, '...') !== false || strpos($value, '••••') !== false || strpos($value, '***') !== false) {
            add_settings_error(
                'weave365_settings_group',
                'weave365_api_key_invalid',
                'Invalid API Key: Masked or truncated key values cannot be saved. Please paste the complete unmasked key.',
                'error'
            );
            return get_option(self::OPTION_API_KEY, '');
        }
        return $value;
    }

    /**
     * Sanitize auto-forward toggle; strictly forces '0' if Order API is not allowed.
     *
     * @param mixed $value
     * @return string
     */
    public function sanitize_auto_forward_orders($value) {
        if (get_option(self::OPTION_ORDERS_API_ALLOWED, '0') !== '1') {
            return '0';
        }
        return ($value === '1' || $value === 1 || $value === true || $value === 'on' || $value === 'yes') ? '1' : '0';
    }

    /**
     * Sanitize COD auto-forward toggle; strictly forces '0' if Order API is not allowed.
     *
     * @param mixed $value
     * @return string
     */
    public function sanitize_forward_cod_orders($value) {
        if (get_option(self::OPTION_ORDERS_API_ALLOWED, '0') !== '1') {
            return '0';
        }
        return ($value === '1' || $value === 1 || $value === true || $value === 'on' || $value === 'yes') ? '1' : '0';
    }

    /**
     * Sanitize packing preference option.
     *
     * @param mixed $value
     * @return string
     */
    public function sanitize_packing_preference($value) {
        $clean = sanitize_text_field(trim((string) $value));
        if ($clean === '') {
            return self::DEFAULT_PACKING_PREFERENCE;
        }
        return $clean;
    }

    /**
     * Triggered when weave365_api_key is updated.
     */
    public function handle_api_key_changed($old_value, $new_value, $option = '') {
        $this->verify_account_capabilities(true);
    }

    /**
     * Triggered when weave365_api_key is added for the first time.
     */
    public function handle_api_key_added($option, $value) {
        $this->verify_account_capabilities(true);
    }

    /**
     * Reset local entitlement state and disable automated order forwarding.
     */
    private function revoke_order_entitlement() {
        update_option(self::OPTION_ORDERS_API_ALLOWED, '0', false);
        update_option(self::OPTION_AUTO_FORWARD_ORDERS, '0', false);
        update_option(self::OPTION_ACCOUNT_TIER, '', false);
        update_option(self::OPTION_CLIENT_NAME, '', false);
        update_option(self::OPTION_REMAINING_QUOTA, 0, false);
    }

    /**
     * Verify API key capabilities and Order API entitlement via GET /api/v1/me.
     *
     * Caches verification state for 6 hours via transient weave365_capabilities_checked.
     * Immediately resets entitlement and disables forwarding if key is cleared or returns 401/403.
     *
     * @param bool $force_refresh Bypass the 6-hour transient cache when true.
     * @return array{success:bool,orders_enabled:bool,tier:string,client_name:string,remaining_quota:int,message:string}
     */
    public function verify_account_capabilities($force_refresh = false) {
        $api_key = trim((string) get_option(self::OPTION_API_KEY, ''));

        if ($api_key === '') {
            $this->revoke_order_entitlement();
            delete_transient(self::TRANSIENT_CAPABILITIES_CHECKED);
            return [
                'success'         => false,
                'orders_enabled'  => false,
                'tier'            => '',
                'client_name'     => '',
                'remaining_quota' => 0,
                'message'         => 'API Key is empty. Order API entitlement cleared.',
            ];
        }

        if (!$force_refresh) {
            $cached = get_transient(self::TRANSIENT_CAPABILITIES_CHECKED);
            if ($cached !== false && is_array($cached)) {
                $orders_allowed = $this->is_order_api_allowed();
                return [
                    'success'         => isset($cached['status']) && $cached['status'] === 'ok',
                    'orders_enabled'  => $orders_allowed,
                    'tier'            => (string) get_option(self::OPTION_ACCOUNT_TIER, ''),
                    'client_name'     => (string) get_option(self::OPTION_CLIENT_NAME, ''),
                    'remaining_quota' => (int) get_option(self::OPTION_REMAINING_QUOTA, 0),
                    'message'         => isset($cached['message']) ? (string) $cached['message'] : 'Using cached capability status.',
                ];
            }
        }

        $response = wp_remote_get(self::API_BASE_URL . '/me', [
            'headers' => [
                'X-API-Key'  => $api_key,
                'Accept'     => 'application/json',
                'User-Agent' => 'Weave365-WooCommerce-Sync/' . self::VERSION,
            ],
            'timeout'   => 10,
            'sslverify' => true,
        ]);

        if (is_wp_error($response)) {
            $err_msg = 'Unable to verify Weave365 permissions: ' . $response->get_error_message();
            return [
                'success'         => false,
                'orders_enabled'  => $this->is_order_api_allowed(),
                'tier'            => (string) get_option(self::OPTION_ACCOUNT_TIER, ''),
                'client_name'     => (string) get_option(self::OPTION_CLIENT_NAME, ''),
                'remaining_quota' => (int) get_option(self::OPTION_REMAINING_QUOTA, 0),
                'message'         => $err_msg,
            ];
        }

        $http_code = (int) wp_remote_retrieve_response_code($response);
        $body_raw  = wp_remote_retrieve_body($response);
        $body      = json_decode($body_raw, true);
        $json_ok   = (json_last_error() === JSON_ERROR_NONE && is_array($body));

        // Invalid, expired, deactivated, or revoked API key
        if ($http_code === 401 || $http_code === 403) {
            $this->revoke_order_entitlement();

            $api_msg = ($json_ok && !empty($body['message']))
                ? sanitize_text_field((string) $body['message'])
                : (($json_ok && !empty($body['error']))
                    ? sanitize_text_field((string) $body['error'])
                    : sprintf('API key verification failed (HTTP %d).', $http_code));

            set_transient(self::TRANSIENT_CAPABILITIES_CHECKED, [
                'checked_at' => time(),
                'status'     => 'error',
                'http_code'  => $http_code,
                'message'    => $api_msg,
            ], 6 * HOUR_IN_SECONDS);

            return [
                'success'         => false,
                'orders_enabled'  => false,
                'tier'            => '',
                'client_name'     => '',
                'remaining_quota' => 0,
                'message'         => $api_msg,
            ];
        }

        if ($http_code !== 200 || !$json_ok) {
            $api_msg = ($json_ok && !empty($body['message']))
                ? sanitize_text_field((string) $body['message'])
                : sprintf('Unexpected response from Weave365 /api/v1/me (HTTP %d).', $http_code);

            return [
                'success'         => false,
                'orders_enabled'  => $this->is_order_api_allowed(),
                'tier'            => (string) get_option(self::OPTION_ACCOUNT_TIER, ''),
                'client_name'     => (string) get_option(self::OPTION_CLIENT_NAME, ''),
                'remaining_quota' => (int) get_option(self::OPTION_REMAINING_QUOTA, 0),
                'message'         => $api_msg,
            ];
        }

        $orders_enabled  = !empty($body['orders_enabled']);
        $tier            = isset($body['tier']) ? sanitize_text_field((string) $body['tier']) : '';
        $client_name     = isset($body['client_name']) ? sanitize_text_field((string) $body['client_name']) : '';
        $remaining_quota = (isset($body['remaining_quota']) && is_numeric($body['remaining_quota']))
            ? max(0, (int) $body['remaining_quota'])
            : 0;

        update_option(self::OPTION_ORDERS_API_ALLOWED, $orders_enabled ? '1' : '0', false);
        update_option(self::OPTION_ACCOUNT_TIER, $tier, false);
        update_option(self::OPTION_CLIENT_NAME, $client_name, false);
        update_option(self::OPTION_REMAINING_QUOTA, $remaining_quota, false);

        if (!$orders_enabled) {
            update_option(self::OPTION_AUTO_FORWARD_ORDERS, '0', false);
        }

        $status_msg = $orders_enabled
            ? 'Permissions verified: Automated Order Fulfillment is unlocked.'
            : 'Permissions verified: Order API is not enabled for this API key.';

        set_transient(self::TRANSIENT_CAPABILITIES_CHECKED, [
            'checked_at'     => time(),
            'status'         => 'ok',
            'orders_enabled' => $orders_enabled,
            'message'        => $status_msg,
        ], 6 * HOUR_IN_SECONDS);

        return [
            'success'         => true,
            'orders_enabled'  => $orders_enabled,
            'tier'            => $tier,
            'client_name'     => $client_name,
            'remaining_quota' => $remaining_quota,
            'message'         => $status_msg,
        ];
    }

    /**
     * Handle manual stock sync via admin-post.php (Post-Redirect-Get pattern).
     */
    public function handle_manual_sync() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'weave365'));
        }
        check_admin_referer('weave365_manual_sync_action', 'weave365_manual_sync_nonce');

        $result = $this->execute_stock_sync();

        $redirect_url = add_query_arg([
            'page'        => 'weave365-sync',
            'sync_result' => !empty($result['success']) ? 'success' : 'error',
            'sync_msg'    => !empty($result['message']) ? $result['message'] : 'Sync executed.',
        ], admin_url('admin.php'));

        wp_safe_redirect($redirect_url);
        exit;
    }

    /**
     * Handle manual "Refresh Permissions" action via admin-post.php (Post-Redirect-Get pattern).
     */
    public function handle_refresh_capabilities() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'weave365'));
        }
        check_admin_referer('weave365_refresh_capabilities_action', 'weave365_refresh_capabilities_nonce');

        $result = $this->verify_account_capabilities(true);

        if (empty($result['success'])) {
            $cap_result = 'error';
        } elseif (!empty($result['orders_enabled'])) {
            $cap_result = 'enabled';
        } else {
            $cap_result = 'disabled';
        }

        $redirect_url = add_query_arg([
            'page'       => 'weave365-sync',
            'cap_result' => $cap_result,
            'cap_msg'    => !empty($result['message']) ? $result['message'] : 'Permissions checked.',
        ], admin_url('admin.php'));

        wp_safe_redirect($redirect_url);
        exit;
    }

    public function render_settings_page() {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }

        $api_key = trim((string) get_option(self::OPTION_API_KEY, ''));

        // Refresh cached account capabilities if 6h transient expired (skipped right after PRG refresh)
        if ($api_key !== '' && !isset($_GET['cap_result'])) {
            $this->verify_account_capabilities(false);
        }

        $orders_allowed  = $this->is_order_api_allowed();
        $account_tier    = (string) get_option(self::OPTION_ACCOUNT_TIER, '');
        $client_name     = (string) get_option(self::OPTION_CLIENT_NAME, '');
        $remaining_quota = (int) get_option(self::OPTION_REMAINING_QUOTA, 0);
        $cap_cache       = get_transient(self::TRANSIENT_CAPABILITIES_CHECKED);

        $last_sync_time   = (string) get_option(self::OPTION_LAST_SYNC_TIME, 'Never');
        $last_sync_status = (string) get_option(self::OPTION_LAST_SYNC_STATUS, 'Not configured');

        $auto_forward = $orders_allowed && (get_option(self::OPTION_AUTO_FORWARD_ORDERS, '0') === '1');
        $forward_cod  = $orders_allowed && (get_option(self::OPTION_FORWARD_COD_ORDERS, '0') === '1');
        $sender_name  = (string) get_option(self::OPTION_SENDER_NAME, '');
        if ($sender_name === '') {
            $sender_name = (string) get_bloginfo('name');
        }
        $sender_phone = (string) get_option(self::OPTION_SENDER_PHONE, '');
        $packing_pref = (string) get_option(self::OPTION_PACKING_PREFERENCE, self::DEFAULT_PACKING_PREFERENCE);
        if ($packing_pref === '') {
            $packing_pref = self::DEFAULT_PACKING_PREFERENCE;
        }
        $packing_options = $this->get_packing_preferences();
        if (!in_array($packing_pref, $packing_options, true)) {
            $packing_options[] = $packing_pref;
        }
        ?>
        <style>
            .w365-wrap {
                max-width: 880px;
                color: #0f172a;
            }
            .w365-header {
                display: flex;
                flex-wrap: wrap;
                align-items: center;
                gap: 12px;
                margin-bottom: 6px;
            }
            .w365-header h1 {
                margin: 0;
                font-size: 1.625rem;
                line-height: 1.3;
                color: #0f172a;
            }
            .w365-version-pill {
                display: inline-flex;
                align-items: center;
                background: #e0f2fe;
                color: #075985;
                border: 1px solid #7dd3fc;
                padding: 3px 10px;
                border-radius: 9999px;
                font-size: 12px;
                font-weight: 700;
            }
            .w365-subtitle {
                color: #475569;
                font-size: 14px;
                line-height: 1.5;
                margin: 4px 0 18px;
            }
            .w365-card {
                background: #ffffff;
                border: 1px solid #94a3b8;
                border-radius: 8px;
                padding: 20px 24px;
                margin-top: 18px;
                box-shadow: 0 1px 3px rgba(15, 23, 42, 0.06);
            }
            .w365-card-title-row {
                display: flex;
                flex-wrap: wrap;
                justify-content: space-between;
                align-items: center;
                gap: 12px;
                margin-bottom: 14px;
            }
            .w365-card h2 {
                margin: 0;
                font-size: 1.125rem;
                color: #0f172a;
            }
            .w365-badge {
                display: inline-flex;
                align-items: center;
                gap: 6px;
                padding: 4px 10px;
                border-radius: 9999px;
                font-size: 12px;
                font-weight: 700;
                line-height: 1.2;
                border: 1px solid transparent;
            }
            .w365-badge-active {
                background: #dcfce7;
                color: #14532d;
                border-color: #16a34a;
            }
            .w365-badge-locked {
                background: #fef3c7;
                color: #78350f;
                border-color: #d97706;
            }
            .w365-field {
                display: flex;
                flex-direction: column;
                align-items: flex-start;
                gap: 6px;
                margin-block-end: 18px;
            }
            .w365-field label {
                font-weight: 600;
                color: #0f172a;
                font-size: 14px;
            }
            .w365-input-row {
                display: flex;
                flex-wrap: wrap;
                align-items: center;
                gap: 8px;
                width: 100%;
                max-width: 560px;
            }
            .w365-input,
            .w365-select {
                font-size: max(1rem, 14px);
                min-height: 44px;
                padding: 8px 12px;
                border: 1px solid #64748b;
                border-radius: 6px;
                color: #0f172a;
                background: #ffffff;
                box-sizing: border-box;
                width: 100%;
                max-width: 460px;
            }
            .w365-input-mono {
                font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
                flex: 1 1 280px;
            }
            .w365-btn-inline {
                min-height: 44px;
                padding: 0 14px;
                border: 1px solid #475569;
                border-radius: 6px;
                background: #f8fafc;
                color: #0f172a;
                font-weight: 600;
                cursor: pointer;
            }
            .w365-btn-inline:hover {
                background: #e2e8f0;
            }
            .w365-help {
                margin: 0;
                font-size: 13px;
                color: #475569;
                line-height: 1.5;
            }
            .w365-divider {
                border: 0;
                border-top: 1px solid #cbd5e1;
                margin: 22px 0;
            }
            .w365-status-bar {
                display: flex;
                flex-wrap: wrap;
                justify-content: space-between;
                align-items: center;
                gap: 14px;
                background: #f8fafc;
                border: 1px solid #cbd5e1;
                border-radius: 6px;
                padding: 14px 18px;
            }
            .w365-meta-grid {
                display: flex;
                flex-wrap: wrap;
                gap: 16px;
                font-size: 13px;
                color: #334155;
            }
            .w365-guard-box {
                margin-top: 14px;
                background: #f0fdf4;
                border: 1px solid #86efac;
                border-radius: 6px;
                padding: 14px 18px;
                color: #14532d;
            }
            .w365-locked-banner {
                background: #fffbeb;
                border: 1px solid #d97706;
                border-inline-start: 4px solid #b45309;
                border-radius: 6px;
                padding: 14px 18px;
                margin-bottom: 16px;
                color: #451a03;
                font-size: 13px;
                line-height: 1.5;
            }
            .w365-fieldset {
                border: 1px solid #cbd5e1;
                border-radius: 6px;
                padding: 16px 18px;
                margin: 0 0 18px;
            }
            .w365-fieldset legend {
                font-weight: 700;
                font-size: 14px;
                color: #0f172a;
                padding: 0 6px;
            }
            .w365-fieldset:disabled {
                background: #f8fafc;
            }
            .w365-fieldset:disabled legend,
            .w365-fieldset:disabled .w365-toggle-label {
                color: #334155;
            }
            .w365-toggle-row {
                display: flex;
                align-items: flex-start;
                gap: 12px;
                margin-block-end: 14px;
            }
            .w365-toggle-row:last-child {
                margin-block-end: 0;
            }
            .w365-toggle-label {
                display: inline-flex;
                flex-direction: column;
                gap: 4px;
                min-height: 44px;
                cursor: pointer;
                font-size: 14px;
                color: #0f172a;
            }
            .w365-switch {
                -webkit-appearance: auto;
                appearance: auto;
                accent-color: #0369a1;
                margin: 0;
                inline-size: 1.5rem;
                block-size: 1.5rem;
                min-inline-size: 24px;
                min-block-size: 24px;
                flex-shrink: 0;
                cursor: pointer;
            }
            .w365-switch:not(.w365-switch-fallback):checked::before {
                content: none;
            }
            .w365-switch.w365-switch-fallback {
                -webkit-appearance: none;
                appearance: none;
                inline-size: 44px;
                min-inline-size: 44px;
                block-size: 24px;
                min-block-size: 24px;
                padding: 0;
                margin: 0;
                border-radius: 9999px;
                border: 2px solid #475569;
                background: #cbd5e1;
                box-shadow: none;
                position: relative;
                vertical-align: middle;
                flex-shrink: 0;
            }
            .w365-switch.w365-switch-fallback::before,
            .w365-switch.w365-switch-fallback:checked::before {
                content: "";
                position: absolute;
                top: 2px;
                left: 2px;
                margin: 0;
                float: none;
                display: block;
                inline-size: 16px;
                block-size: 16px;
                border-radius: 50%;
                background: #ffffff;
                border: 1px solid #334155;
            }
            .w365-switch.w365-switch-fallback:checked {
                background: #0369a1;
                border-color: #075985;
            }
            .w365-switch.w365-switch-fallback:checked::before {
                transform: translateX(20px);
            }
            @media (prefers-reduced-motion: no-preference) {
                .w365-switch.w365-switch-fallback,
                .w365-switch.w365-switch-fallback::before {
                    transition: background-color 150ms ease, transform 150ms ease;
                }
            }
            .w365-switch:disabled,
            .w365-switch:disabled + .w365-toggle-label {
                cursor: not-allowed;
                opacity: 0.65;
            }
            .w365-wrap :is(input, select, button, a):focus-visible {
                outline: 3px solid #0b57d0;
                outline-offset: 2px;
            }
            .w365-guide-box {
                background: #f1f5f9;
                border: 1px solid #cbd5e1;
                border-inline-start: 4px solid #0369a1;
                padding: 16px 20px;
                border-radius: 6px;
                margin-top: 20px;
            }
            .w365-guide-box h2 {
                margin: 0 0 10px;
                font-size: 1rem;
                color: #0f172a;
            }
            .w365-guide-box ol {
                margin: 0;
                padding-inline-start: 20px;
                font-size: 13px;
                color: #1e293b;
                line-height: 1.6;
            }
            .w365-sr-only {
                position: absolute;
                clip-path: inset(50%);
                overflow: hidden;
                width: 1px;
                height: 1px;
                margin: -1px;
                padding: 0;
                border: 0;
                white-space: nowrap;
            }
            @media (forced-colors: active) {
                .w365-card,
                .w365-status-bar,
                .w365-fieldset,
                .w365-badge,
                .w365-locked-banner,
                .w365-guard-box {
                    border: 1px solid CanvasText;
                }
                .w365-switch.w365-switch-fallback {
                    border: 2px solid ButtonText;
                    background: Canvas;
                }
                .w365-switch.w365-switch-fallback:checked {
                    background: Highlight;
                }
                .w365-switch.w365-switch-fallback::before {
                    background: ButtonText;
                }
            }
        </style>

        <div class="wrap w365-wrap">
            <div class="w365-header">
                <h1>Weave365 WooCommerce Sync</h1>
                <span class="w365-version-pill">v<?php echo esc_html(self::VERSION); ?></span>
            </div>
            <p class="w365-subtitle">
                Keep your WooCommerce store's Banarasi handloom inventory synced with live artisan looms in real time, protect checkout against overselling, and optionally automate wholesale order fulfillment.
            </p>

            <?php
            settings_errors();

            if (isset($_GET['sync_result'])) {
                $sync_result = sanitize_key($_GET['sync_result']);
                $sync_msg    = isset($_GET['sync_msg']) ? sanitize_text_field(wp_unslash($_GET['sync_msg'])) : '';
                if ($sync_result === 'success') {
                    echo '<div class="notice notice-success is-dismissible" role="status"><p><strong>&#10003; Sync Successful:</strong> ' . esc_html($sync_msg) . '</p></div>';
                } else {
                    echo '<div class="notice notice-error is-dismissible" role="alert"><p><strong>&#9888; Sync Failed:</strong> ' . esc_html($sync_msg) . '</p></div>';
                }
            }

            if (isset($_GET['cap_result'])) {
                $cap_result = sanitize_key($_GET['cap_result']);
                $cap_msg    = isset($_GET['cap_msg']) ? sanitize_text_field(wp_unslash($_GET['cap_msg'])) : '';
                if ($cap_result === 'enabled') {
                    echo '<div class="notice notice-success is-dismissible" role="status"><p><strong>&#10003; Permissions Refreshed:</strong> ' . esc_html($cap_msg) . '</p></div>';
                } elseif ($cap_result === 'disabled') {
                    echo '<div class="notice notice-warning is-dismissible" role="status"><p><strong>&#128274; Permissions Refreshed:</strong> ' . esc_html($cap_msg) . '</p></div>';
                } else {
                    echo '<div class="notice notice-error is-dismissible" role="alert"><p><strong>&#9888; Permission Check Failed:</strong> ' . esc_html($cap_msg) . '</p></div>';
                }
            } elseif (is_array($cap_cache) && isset($cap_cache['status']) && $cap_cache['status'] === 'error' && !empty($cap_cache['message'])) {
                echo '<div class="notice notice-error" role="alert"><p><strong>&#9888; API Key Verification Error:</strong> ' . esc_html((string) $cap_cache['message']) . '</p></div>';
            }
            ?>

            <section class="w365-card" aria-labelledby="w365-api-heading">
                <div class="w365-card-title-row">
                    <h2 id="w365-api-heading">Account &amp; API Key Configuration</h2>
                    <?php if ($api_key !== '') : ?>
                        <span class="w365-badge <?php echo $orders_allowed ? 'w365-badge-active' : 'w365-badge-locked'; ?>">
                            <span aria-hidden="true"><?php echo $orders_allowed ? '&#10003;' : '&#128274;'; ?></span>
                            <span><?php echo $orders_allowed ? 'Order API Enabled' : 'Stock Sync Only'; ?></span>
                        </span>
                    <?php endif; ?>
                </div>

                <form method="post" action="options.php" aria-labelledby="w365-api-heading" class="w365-disable-on-submit">
                    <?php settings_fields('weave365_settings_group'); ?>

                    <div class="w365-field">
                        <label for="weave365_api_key">Weave365 Live API Key</label>
                        <div class="w365-input-row">
                            <input
                                type="password"
                                id="weave365_api_key"
                                name="<?php echo esc_attr(self::OPTION_API_KEY); ?>"
                                value="<?php echo esc_attr($api_key); ?>"
                                class="w365-input w365-input-mono"
                                placeholder="w365_live_..."
                                autocomplete="off"
                                autocorrect="off"
                                autocapitalize="none"
                                spellcheck="false"
                                aria-describedby="weave365_api_key_help"
                            />
                            <button
                                type="button"
                                id="w365_toggle_api_key"
                                class="w365-btn-inline"
                                aria-pressed="false"
                                aria-controls="weave365_api_key"
                                aria-describedby="w365_toggle_key_warning"
                            >Show</button>
                            <span id="w365_toggle_key_warning" class="w365-sr-only">Warning: this displays your secret API key on screen.</span>
                        </div>
                        <p id="weave365_api_key_help" class="w365-help">
                            Paste your full Live API Key from your <a href="https://www.weave365.com/account?tab=developer" target="_blank" rel="noopener noreferrer">Weave365 Developer Dashboard</a>. Saving automatically verifies your account capabilities.
                        </p>
                    </div>

                    <?php submit_button('Save API Key', 'primary', 'w365_save_api_key', false); ?>
                </form>

                <hr class="w365-divider" />

                <div class="w365-status-bar">
                    <div>
                        <div style="font-size: 13px; font-weight: 700; color: #0f172a; margin-bottom: 4px;">Connected Developer Account</div>
                        <?php if ($api_key === '') : ?>
                            <div class="w365-help">No API key saved yet. Save your key above to verify your tier and capabilities.</div>
                        <?php else : ?>
                            <div class="w365-meta-grid">
                                <span><strong>Client:</strong> <?php echo esc_html($client_name !== '' ? $client_name : 'Unverified'); ?></span>
                                <span><strong>Tier:</strong> <?php echo esc_html($account_tier !== '' ? ucfirst($account_tier) : 'Unknown'); ?></span>
                                <span><strong>Remaining Monthly Quota:</strong> <?php echo esc_html((string) number_format_i18n($remaining_quota)); ?></span>
                                <?php if (is_array($cap_cache) && !empty($cap_cache['checked_at'])) : ?>
                                    <span><strong>Last Checked:</strong> <?php echo esc_html(wp_date(get_option('date_format') . ' ' . get_option('time_format'), (int) $cap_cache['checked_at'])); ?></span>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" aria-label="Refresh Weave365 account permissions" class="w365-disable-on-submit" style="margin: 0;">
                        <input type="hidden" name="action" value="weave365_refresh_capabilities" />
                        <?php wp_nonce_field('weave365_refresh_capabilities_action', 'weave365_refresh_capabilities_nonce'); ?>
                        <button type="submit" class="button button-secondary" style="min-height: 44px; padding: 0 16px;">
                            Refresh Permissions
                        </button>
                    </form>
                </div>
            </section>

            <section class="w365-card" aria-labelledby="w365-sync-heading">
                <div class="w365-card-title-row">
                    <h2 id="w365-sync-heading">Automated Stock Sync &amp; Checkout Guard</h2>
                    <span class="w365-badge w365-badge-active">
                        <span aria-hidden="true">&#10003;</span>
                        <span>Mandatory &bull; Active</span>
                    </span>
                </div>

                <div class="w365-status-bar">
                    <div>
                        <div style="font-size: 13px; font-weight: 700; color: #0f172a;">Automated Background Sync</div>
                        <div class="w365-help">
                            Runs automatically <strong><?php echo esc_html(apply_filters('weave365_sync_interval', 'hourly')); ?></strong> via WordPress WP-Cron.<br />
                            <strong>Last Sync:</strong> <?php echo esc_html($last_sync_time); ?> &bull;
                            <strong>Status:</strong> <?php echo esc_html($last_sync_status); ?>
                        </div>
                    </div>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" aria-label="Run manual stock sync" class="w365-disable-on-submit" style="margin: 0;">
                        <input type="hidden" name="action" value="weave365_manual_sync" />
                        <?php wp_nonce_field('weave365_manual_sync_action', 'weave365_manual_sync_nonce'); ?>
                        <button type="submit" class="button button-secondary" style="min-height: 44px; padding: 0 16px;">
                            Sync Stock Now
                        </button>
                    </form>
                </div>

                <div class="w365-guard-box">
                    <div style="font-size: 13px; font-weight: 700;">
                        <span aria-hidden="true">&#10003;</span> Real-Time Checkout Stock Guard
                    </div>
                    <p style="font-size: 12px; margin: 4px 0 0; line-height: 1.5; color: #14532d;">
                        Whenever a customer proceeds through cart or clicks <em>Place Order</em> (Classic Checkout or WooCommerce Blocks), the plugin verifies live loom stock before payment is accepted. If an item sells out between hourly syncs, checkout is blocked and local stock is updated automatically.
                    </p>
                </div>
            </section>

            <section class="w365-card" aria-labelledby="w365-orders-heading">
                <div class="w365-card-title-row">
                    <h2 id="w365-orders-heading">Automated Order Fulfillment</h2>
                    <?php if ($orders_allowed) : ?>
                        <span class="w365-badge w365-badge-active">
                            <span aria-hidden="true">&#10003;</span>
                            <span>Unlocked &bull; Ready</span>
                        </span>
                    <?php else : ?>
                        <span class="w365-badge w365-badge-locked">
                            <span aria-hidden="true">&#128274;</span>
                            <span>Locked</span>
                        </span>
                    <?php endif; ?>
                </div>

                <?php if (!$orders_allowed) : ?>
                    <div id="w365_orders_locked_notice" class="w365-locked-banner" role="note">
                        <strong><span aria-hidden="true">&#128274;</span> Order API Not Enabled</strong> &mdash; Upgrade or request Order API access from your <a href="https://www.weave365.com/account?tab=developer" target="_blank" rel="noopener noreferrer">Weave365 Developer Dashboard</a> to unlock automated order forwarding. Once enabled, click <strong>Refresh Permissions</strong> above.
                    </div>

                    <fieldset class="w365-fieldset" disabled>
                        <legend>Order Forwarding Controls (Locked)</legend>
                        <div class="w365-toggle-row">
                            <input
                                type="checkbox"
                                switch
                                id="weave365_auto_forward_orders_locked"
                                class="w365-switch"
                                disabled
                                aria-describedby="w365_orders_locked_notice"
                            />
                            <label for="weave365_auto_forward_orders_locked" class="w365-toggle-label">
                                <strong>Auto-forward paid WooCommerce orders to Weave365</strong>
                                <span class="w365-help">Locked until Order API access is enabled for your API key.</span>
                            </label>
                        </div>
                    </fieldset>
                <?php else : ?>
                    <p class="w365-help" style="margin-bottom: 14px;">
                        Opt in to automatically forward paid WooCommerce orders containing Weave365 SKUs to Weave365 Wholesale Fulfillment. Non-Weave365 items in mixed carts are automatically filtered out.
                    </p>

                    <form method="post" action="options.php" aria-labelledby="w365-orders-heading" class="w365-disable-on-submit">
                        <?php settings_fields('weave365_order_settings_group'); ?>

                        <fieldset class="w365-fieldset">
                            <legend>Order Forwarding &amp; Parcel Slip Settings</legend>

                            <div class="w365-toggle-row">
                                <input
                                    type="checkbox"
                                    switch
                                    id="weave365_auto_forward_orders"
                                    name="<?php echo esc_attr(self::OPTION_AUTO_FORWARD_ORDERS); ?>"
                                    value="1"
                                    class="w365-switch"
                                    <?php checked($auto_forward, true); ?>
                                    aria-describedby="w365_auto_forward_help"
                                />
                                <label for="weave365_auto_forward_orders" class="w365-toggle-label">
                                    <strong>Auto-forward paid WooCommerce orders to Weave365</strong>
                                    <span id="w365_auto_forward_help" class="w365-help">
                                        Forwards orders once payment completes or status reaches <code>processing</code>. Pending, failed, cancelled, refunded, and draft orders are never forwarded.
                                    </span>
                                </label>
                            </div>

                            <div class="w365-toggle-row">
                                <input
                                    type="checkbox"
                                    switch
                                    id="weave365_forward_cod_orders"
                                    name="<?php echo esc_attr(self::OPTION_FORWARD_COD_ORDERS); ?>"
                                    value="1"
                                    class="w365-switch"
                                    <?php checked($forward_cod, true); ?>
                                    aria-describedby="w365_forward_cod_help"
                                />
                                <label for="weave365_forward_cod_orders" class="w365-toggle-label">
                                    <strong>Also auto-forward Cash on Delivery (COD) orders when placed</strong>
                                    <span id="w365_forward_cod_help" class="w365-help">
                                        Applies to WooCommerce <code>cod</code> orders entering <code>on-hold</code> or <code>processing</code> when auto-forwarding is enabled above.
                                    </span>
                                </label>
                            </div>

                            <hr class="w365-divider" />

                            <div class="w365-field">
                                <label for="weave365_sender_name">Reseller / Sender Name (Optional)</label>
                                <input
                                    type="text"
                                    id="weave365_sender_name"
                                    name="<?php echo esc_attr(self::OPTION_SENDER_NAME); ?>"
                                    value="<?php echo esc_attr($sender_name); ?>"
                                    class="w365-input"
                                    autocomplete="organization"
                                    aria-describedby="w365_sender_name_help"
                                />
                                <p id="w365_sender_name_help" class="w365-help">
                                    Displayed as the sender on white-label courier slips. Defaults to your store name (<code><?php echo esc_html(get_bloginfo('name')); ?></code>).
                                </p>
                            </div>

                            <div class="w365-field">
                                <label for="weave365_sender_phone">Sender Contact Phone (Optional)</label>
                                <input
                                    type="tel"
                                    id="weave365_sender_phone"
                                    name="<?php echo esc_attr(self::OPTION_SENDER_PHONE); ?>"
                                    value="<?php echo esc_attr($sender_phone); ?>"
                                    class="w365-input"
                                    autocomplete="tel"
                                    inputmode="tel"
                                    placeholder="+91 98XXXXXXXX"
                                    aria-describedby="w365_sender_phone_help"
                                />
                                <p id="w365_sender_phone_help" class="w365-help">
                                    Optional return/support phone number printed on the wholesale courier parcel slip.
                                </p>
                            </div>

                            <div class="w365-field" style="margin-block-end: 0;">
                                <label for="weave365_packing_preference">Packing Preference (Optional)</label>
                                <select
                                    id="weave365_packing_preference"
                                    name="<?php echo esc_attr(self::OPTION_PACKING_PREFERENCE); ?>"
                                    class="w365-select"
                                    aria-describedby="w365_packing_help"
                                >
                                    <?php foreach ($packing_options as $option_label) : ?>
                                        <option value="<?php echo esc_attr($option_label); ?>" <?php selected($packing_pref, $option_label); ?>>
                                            <?php echo esc_html($option_label); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <p id="w365_packing_help" class="w365-help">
                                    Select the default packaging instruction transmitted with forwarded orders.
                                </p>
                            </div>
                        </fieldset>

                        <?php submit_button('Save Fulfillment Settings', 'primary', 'w365_save_order_settings', false); ?>
                    </form>
                <?php endif; ?>
            </section>

            <section class="w365-guide-box" aria-labelledby="w365-how-heading">
                <h2 id="w365-how-heading">How SKU Matching &amp; Order Sync Works</h2>
                <ol>
                    <li>Ensure your WooCommerce products or variations have their <strong>SKU</strong> set to the matching Weave365 Product ID or Variant SKU (e.g., <code>102001</code> or <code>102001-1</code>).</li>
                    <li>If you have not imported products yet, download the pre-formatted <strong>CSV Catalog</strong> from the Weave365 Developer Dashboard and use <em>WooCommerce &rarr; Products &rarr; Import</em>.</li>
                    <li>Stock status syncs automatically hourly via <code>/api/v1/stock-status</code>, and live cart/checkout guards verify loom availability in real time before payment.</li>
                    <li>When Order API access is enabled and opted in, paid orders forward idempotently to <code>/api/v1/orders</code> (compatible with both WooCommerce HPOS and legacy order storage). You can also send or retry orders manually from the Order Actions dropdown on any order edit screen.</li>
                </ol>
            </section>
        </div>

        <script>
            (function () {
                if (!('switch' in HTMLInputElement.prototype)) {
                    var switches = document.querySelectorAll('input[type="checkbox"][switch].w365-switch');
                    for (var i = 0; i < switches.length; i++) {
                        switches[i].setAttribute('role', 'switch');
                        switches[i].classList.add('w365-switch-fallback');
                    }
                }

                var toggleBtn = document.getElementById('w365_toggle_api_key');
                var apiInput = document.getElementById('weave365_api_key');
                if (toggleBtn && apiInput) {
                    toggleBtn.addEventListener('click', function () {
                        var isHidden = apiInput.type === 'password';
                        apiInput.type = isHidden ? 'text' : 'password';
                        toggleBtn.setAttribute('aria-pressed', isHidden ? 'true' : 'false');
                        toggleBtn.textContent = isHidden ? 'Hide' : 'Show';
                    });
                }

                var forms = document.querySelectorAll('form.w365-disable-on-submit');
                for (var j = 0; j < forms.length; j++) {
                    forms[j].addEventListener('submit', function (e) {
                        var submitBtn = e.target.querySelector('button[type="submit"], input[type="submit"]');
                        if (submitBtn && !submitBtn.disabled) {
                            setTimeout(function () {
                                submitBtn.disabled = true;
                            }, 0);
                        }
                    });
                }

                window.addEventListener('pageshow', function (event) {
                    if (event.persisted) {
                        var buttons = document.querySelectorAll('form.w365-disable-on-submit [type="submit"]');
                        for (var k = 0; k < buttons.length; k++) {
                            buttons[k].disabled = false;
                        }
                    }
                });
            })();
        </script>
        <?php
    }

    /**
     * Register manual WooCommerce Order Action (works in Legacy and HPOS) when Order API is enabled.
     *
     * @param array         $actions Existing order actions.
     * @param \WC_Order|int $order   Order instance (WC 6+) or null.
     * @return array
     */
    public function register_manual_order_action($actions, $order = null) {
        if (!$this->is_order_api_allowed()) {
            return $actions;
        }

        if ($order && !is_a($order, 'WC_Order') && function_exists('wc_get_order')) {
            $order = wc_get_order($order);
        }

        if ($order && is_a($order, 'WC_Order')) {
            $w365_status = (string) $order->get_meta('_weave365_order_status', true);
            $w365_id     = (string) $order->get_meta('_weave365_order_id', true);
            if ($w365_id !== '' || $w365_status === 'sent' || $w365_status === 'ignored') {
                return $actions;
            }
            if ($w365_status === 'failed') {
                $actions['weave365_send_order'] = __('Retry Send Order to Weave365', 'weave365');
                return $actions;
            }
        }

        $actions['weave365_send_order'] = __('Send Order to Weave365', 'weave365');
        return $actions;
    }

    /**
     * Handle manual Order Action execution from WooCommerce Order Edit screen.
     *
     * @param \WC_Order|int $order
     */
    public function handle_manual_order_action($order) {
        if (!$this->is_order_api_allowed()) {
            return;
        }

        if (!$order || !is_a($order, 'WC_Order')) {
            $order = wc_get_order($order);
        }
        if (!$order || !is_a($order, 'WC_Order')) {
            return;
        }

        $status = (string) $order->get_status();
        if (in_array($status, ['pending', 'failed', 'cancelled', 'refunded', 'checkout-draft', 'trash'], true)) {
            $order->add_order_note(
                sprintf('Weave365 Manual Send Skipped: Order status "%s" is not eligible for wholesale fulfillment.', $status)
            );
            return;
        }

        try {
            $this->send_order_to_weave365($order, true);
        } catch (\Throwable $e) {
            $order->update_meta_data('_weave365_order_status', 'failed');
            $order->update_meta_data('_weave365_order_error', sanitize_text_field($e->getMessage()));
            $order->save();
            $order->add_order_note('Weave365 Order Sync Exception: ' . $e->getMessage());
        }
    }

    /**
     * Register HPOS-compatible read-only Weave365 Fulfillment Status meta box on order edit screen.
     */
    public function register_order_status_meta_box() {
        if (!$this->is_order_api_allowed()) {
            return;
        }

        $screen = function_exists('wc_get_page_screen_id')
            ? wc_get_page_screen_id('shop-order')
            : 'shop_order';

        add_meta_box(
            'weave365_order_sync_status',
            __('Weave365 Fulfillment Status', 'weave365'),
            [$this, 'render_order_status_meta_box'],
            $screen,
            'side',
            'default'
        );
    }

    /**
     * Render HPOS-compatible read-only status meta box on WooCommerce order edit screen.
     *
     * @param \WC_Order|\WP_Post $post_or_order_object
     */
    public function render_order_status_meta_box($post_or_order_object) {
        $order = ($post_or_order_object instanceof \WC_Order)
            ? $post_or_order_object
            : wc_get_order(isset($post_or_order_object->ID) ? $post_or_order_object->ID : 0);

        if (!$order || !is_a($order, 'WC_Order')) {
            echo '<p>' . esc_html__('Order details unavailable.', 'weave365') . '</p>';
            return;
        }

        $status       = (string) $order->get_meta('_weave365_order_status', true);
        $w365_id      = (string) $order->get_meta('_weave365_order_id', true);
        $w365_number  = (string) $order->get_meta('_weave365_order_number', true);
        $payment_link = (string) $order->get_meta('_weave365_payment_link', true);
        $last_error   = (string) $order->get_meta('_weave365_order_error', true);

        echo '<div style="font-size: 13px; line-height: 1.5; color: #0f172a;">';

        if ($status === 'sent' || $w365_id !== '') {
            echo '<p style="margin: 0 0 8px;"><strong style="color: #14532d;">&#10003; Status: Sent to Weave365</strong></p>';
            if ($w365_id !== '') {
                echo '<p style="margin: 0 0 6px;"><strong>Weave365 Order ID:</strong><br /><code>' . esc_html($w365_id) . '</code></p>';
            }
            if ($w365_number !== '') {
                echo '<p style="margin: 0 0 6px;"><strong>Order Number:</strong> ' . esc_html($w365_number) . '</p>';
            }
            if ($payment_link !== '') {
                echo '<p style="margin: 8px 0 0;"><a class="button button-primary" href="' . esc_url($payment_link) . '" target="_blank" rel="noopener noreferrer">Pay Wholesale Invoice</a></p>';
            }
        } elseif ($status === 'failed') {
            echo '<p style="margin: 0 0 8px;"><strong style="color: #991b1b;">&#9888; Status: Failed</strong></p>';
            if ($last_error !== '') {
                echo '<p style="margin: 0 0 8px; padding: 8px; background: #fef2f2; border: 1px solid #fca5a5; border-radius: 4px; color: #7f1d1d;">' . esc_html($last_error) . '</p>';
            }
            echo '<p style="margin: 0; color: #475569;">Use <em>Order actions &rarr; Retry Send Order to Weave365</em> above to retry.</p>';
        } elseif ($status === 'ignored') {
            echo '<p style="margin: 0 0 6px;"><strong style="color: #475569;">&mdash; Status: Ignored</strong></p>';
            echo '<p style="margin: 0; color: #475569;">Order contains no Weave365 SKUs and was skipped.</p>';
        } else {
            echo '<p style="margin: 0 0 6px;"><strong>Status: Not Sent</strong></p>';
            echo '<p style="margin: 0; color: #475569;">Use <em>Order actions &rarr; Send Order to Weave365</em> to forward manually.</p>';
        }

        echo '</div>';
    }

    /**
     * Auto-forward handler for woocommerce_payment_complete and woocommerce_order_status_processing.
     *
     * @param int            $order_id
     * @param \WC_Order|null $order
     */
    public function handle_auto_forward_order($order_id, $order = null) {
        $this->dispatch_auto_forward($order_id, $order, false);
    }

    /**
     * Auto-forward handler for woocommerce_order_status_on-hold (COD orders only).
     *
     * @param int            $order_id
     * @param \WC_Order|null $order
     */
    public function handle_auto_forward_cod_on_hold($order_id, $order = null) {
        $this->dispatch_auto_forward($order_id, $order, true);
    }

    /**
     * Guarded auto-forward dispatcher ensuring paid/eligible status, COD rules, and exception safety.
     *
     * @param int            $order_id
     * @param \WC_Order|null $order
     * @param bool           $is_on_hold_hook
     */
    private function dispatch_auto_forward($order_id, $order = null, $is_on_hold_hook = false) {
        if (!$this->is_order_api_allowed() || get_option(self::OPTION_AUTO_FORWARD_ORDERS, '0') !== '1') {
            return;
        }

        if (!function_exists('wc_get_order')) {
            return;
        }

        try {
            if (!$order || !is_a($order, 'WC_Order')) {
                $order = wc_get_order($order_id);
            }
            if (!$order || !is_a($order, 'WC_Order')) {
                return;
            }
            if ($order->get_type() === 'shop_order_refund') {
                return;
            }

            $status         = (string) $order->get_status();
            $payment_method = (string) $order->get_payment_method();
            $is_cod         = ($payment_method === 'cod');
            $cod_enabled    = (get_option(self::OPTION_FORWARD_COD_ORDERS, '0') === '1');

            // Never forward unpaid, cancelled, failed, refunded, or draft orders
            if (in_array($status, ['pending', 'failed', 'cancelled', 'refunded', 'checkout-draft', 'trash'], true)) {
                return;
            }

            // Respect COD opt-in for both on-hold and processing hooks
            if ($is_cod && !$cod_enabled) {
                return;
            }

            // Only allow on-hold for COD when COD forwarding is enabled (never for BACS/Cheque)
            if ($is_on_hold_hook || $status === 'on-hold') {
                if (!$is_cod || !$cod_enabled || $status !== 'on-hold') {
                    return;
                }
            } elseif (!in_array($status, ['processing', 'completed'], true)) {
                return;
            }

            // Prevent duplicate attempts within the same PHP request (e.g. processing + payment_complete)
            static $attempted_in_request = [];
            $oid = (int) $order->get_id();
            if (isset($attempted_in_request[$oid])) {
                return;
            }
            $attempted_in_request[$oid] = true;

            $this->send_order_to_weave365($order, false);
        } catch (\Throwable $e) {
            if (isset($order) && is_a($order, 'WC_Order')) {
                try {
                    $order->update_meta_data('_weave365_order_status', 'failed');
                    $order->update_meta_data('_weave365_order_error', sanitize_text_field($e->getMessage()));
                    $order->save();
                    $order->add_order_note('Weave365 Auto-Forward Error: ' . $e->getMessage());
                } catch (\Throwable $inner) {
                    // Never allow checkout or gateway webhooks to crash
                }
            }
        }
    }

    /**
     * Extract color name from a WooCommerce variation or order line item when available.
     *
     * @param \WC_Order_Item_Product $item
     * @param \WC_Product            $product
     * @return string
     */
    private function extract_item_color($item, $product) {
        if (method_exists($product, 'is_type') && $product->is_type('variation') && method_exists($product, 'get_attributes')) {
            $attrs = $product->get_attributes();
            if (is_array($attrs)) {
                foreach ($attrs as $attr_key => $attr_val) {
                    $key_str = (string) $attr_key;
                    if (stripos($key_str, 'color') !== false || stripos($key_str, 'colour') !== false) {
                        $val_str = trim((string) $attr_val);
                        if ($val_str !== '') {
                            if (function_exists('taxonomy_exists') && taxonomy_exists($key_str) && function_exists('get_term_by')) {
                                $term = get_term_by('slug', $val_str, $key_str);
                                if ($term && !is_wp_error($term) && !empty($term->name)) {
                                    return (string) $term->name;
                                }
                            }
                            return $val_str;
                        }
                    }
                }
            }
        }

        if (method_exists($item, 'get_meta_data')) {
            $meta_items = $item->get_meta_data();
            if (is_array($meta_items)) {
                foreach ($meta_items as $meta) {
                    $meta_key = isset($meta->key) ? (string) $meta->key : '';
                    if ($meta_key === '' || strpos($meta_key, '_') === 0) {
                        continue;
                    }
                    if (stripos($meta_key, 'color') !== false || stripos($meta_key, 'colour') !== false) {
                        $meta_val = isset($meta->value) && is_scalar($meta->value) ? trim((string) $meta->value) : '';
                        if ($meta_val !== '') {
                            if (function_exists('taxonomy_exists') && taxonomy_exists($meta_key) && function_exists('get_term_by')) {
                                $term = get_term_by('slug', $meta_val, $meta_key);
                                if ($term && !is_wp_error($term) && !empty($term->name)) {
                                    return (string) $term->name;
                                }
                            }
                            return $meta_val;
                        }
                    }
                }
            }
        }

        return '';
    }

    /**
     * Send an eligible WooCommerce order to POST /api/v1/orders with idempotency, locking,
     * HPOS-safe meta updates, mixed-cart SKU resolution, and 403 auto-revocation.
     *
     * @param \WC_Order $order
     * @param bool      $is_manual
     * @return array
     */
    public function send_order_to_weave365($order, $is_manual = false) {
        if (!$this->is_order_api_allowed()) {
            return ['success' => false, 'message' => 'Order API is not enabled for this API key.'];
        }

        $api_key = trim((string) get_option(self::OPTION_API_KEY, ''));
        if ($api_key === '') {
            return ['success' => false, 'message' => 'API Key is missing.'];
        }

        if (!$order || !is_a($order, 'WC_Order')) {
            return ['success' => false, 'message' => 'Invalid WooCommerce order object.'];
        }

        $order_id = (int) $order->get_id();
        if ($order_id <= 0) {
            return ['success' => false, 'message' => 'Invalid order ID.'];
        }

        // Strict idempotency check via HPOS-compatible order meta
        $existing_w365_id = trim((string) $order->get_meta('_weave365_order_id', true));
        $existing_status  = trim((string) $order->get_meta('_weave365_order_status', true));
        if ($existing_w365_id !== '' || $existing_status === 'sent' || $existing_status === 'ignored') {
            return ['success' => true, 'skipped' => true, 'message' => 'Order already processed by Weave365.'];
        }

        // Per-order concurrency transient lock (60s TTL)
        $lock_key = 'w365_order_lock_' . $order_id;
        if (get_transient($lock_key)) {
            return ['success' => false, 'locked' => true, 'message' => 'Order forwarding is already in progress.'];
        }

        set_transient($lock_key, time(), 60);

        try {
            // Re-read fresh order state inside lock if available
            $fresh_order = function_exists('wc_get_order') ? wc_get_order($order_id) : null;
            if ($fresh_order && is_a($fresh_order, 'WC_Order')) {
                $order = $fresh_order;
                $recheck_id     = trim((string) $order->get_meta('_weave365_order_id', true));
                $recheck_status = trim((string) $order->get_meta('_weave365_order_status', true));
                if ($recheck_id !== '' || $recheck_status === 'sent' || $recheck_status === 'ignored') {
                    return ['success' => true, 'skipped' => true, 'message' => 'Order already processed by Weave365.'];
                }
            }

            // 1. Collect line items & resolve SKUs (with parent SKU fallback for variations)
            $items = [];
            foreach ($order->get_items('line_item') as $item) {
                $qty = (int) $item->get_quantity();
                if ($qty <= 0) {
                    continue;
                }

                $product = $item->get_product();
                if (!$product || !is_a($product, 'WC_Product')) {
                    continue;
                }

                $sku = trim((string) $product->get_sku());
                if ($sku === '' && $product->is_type('variation')) {
                    $parent_id = $product->get_parent_id();
                    if ($parent_id) {
                        $parent_product = wc_get_product($parent_id);
                        if ($parent_product) {
                            $sku = trim((string) $parent_product->get_sku());
                        }
                    }
                }

                if ($sku === '') {
                    continue;
                }

                $item_payload = [
                    'sku'           => $sku,
                    'quantity'      => $qty,
                    'product_title' => (string) $item->get_name(),
                    'selling_price' => (float) $order->get_item_total($item, true, true),
                ];

                $color = $this->extract_item_color($item, $product);
                if ($color !== '') {
                    $item_payload['color'] = $color;
                }

                $items[] = $item_payload;
            }

            if (empty($items)) {
                $order->update_meta_data('_weave365_order_status', 'ignored');
                $order->delete_meta_data('_weave365_order_error');
                $order->save();
                $order->add_order_note('Weave365 Order Sync: Order marked as ignored because no line items have a product SKU.');
                return ['success' => true, 'ignored' => true, 'message' => 'No line items with SKUs; order ignored.'];
            }

            // 2. Resolve customer & shipping address with graceful billing fallback
            $ship_first = trim((string) $order->get_shipping_first_name());
            $ship_last  = trim((string) $order->get_shipping_last_name());
            $bill_first = trim((string) $order->get_billing_first_name());
            $bill_last  = trim((string) $order->get_billing_last_name());

            $first_name    = $ship_first !== '' ? $ship_first : $bill_first;
            $last_name     = $ship_last !== '' ? $ship_last : $bill_last;
            $ship_name     = trim($ship_first . ' ' . $ship_last);
            $bill_name     = trim($bill_first . ' ' . $bill_last);
            $customer_name = $ship_name !== '' ? $ship_name : $bill_name;

            $ship_addr1 = trim((string) $order->get_shipping_address_1());
            $ship_addr2 = trim((string) $order->get_shipping_address_2());
            $bill_addr1 = trim((string) $order->get_billing_address_1());
            $bill_addr2 = trim((string) $order->get_billing_address_2());

            $address_1   = $ship_addr1 !== '' ? $ship_addr1 : $bill_addr1;
            $address_2   = $ship_addr2 !== '' ? $ship_addr2 : ($ship_addr1 === '' ? $bill_addr2 : '');
            $full_street = implode(', ', array_filter([$address_1, $address_2], function ($part) {
                return $part !== '';
            }));

            $ship_city = trim((string) $order->get_shipping_city());
            $bill_city = trim((string) $order->get_billing_city());
            $city      = $ship_city !== '' ? $ship_city : $bill_city;

            $ship_state = trim((string) $order->get_shipping_state());
            $bill_state = trim((string) $order->get_billing_state());
            $state      = $ship_state !== '' ? $ship_state : $bill_state;

            $ship_postcode     = trim((string) $order->get_shipping_postcode());
            $bill_postcode     = trim((string) $order->get_billing_postcode());
            $customer_postcode = $ship_postcode !== '' ? $ship_postcode : $bill_postcode;

            $ship_country = trim((string) $order->get_shipping_country());
            $bill_country = trim((string) $order->get_billing_country());
            $country      = $ship_country !== '' ? $ship_country : $bill_country;

            $ship_phone     = method_exists($order, 'get_shipping_phone') ? trim((string) $order->get_shipping_phone()) : '';
            $bill_phone     = trim((string) $order->get_billing_phone());
            $customer_phone = $ship_phone !== '' ? $ship_phone : $bill_phone;

            $customer_email = trim((string) $order->get_billing_email());

            // Pre-send validation for required delivery fields
            $missing_fields = [];
            if ($customer_name === '') {
                $missing_fields[] = 'customer name';
            }
            if ($customer_phone === '') {
                $missing_fields[] = 'phone number';
            }
            if ($customer_postcode === '') {
                $missing_fields[] = 'postal/PIN code';
            }

            if (!empty($missing_fields)) {
                $err_msg = 'Missing required delivery field(s): ' . implode(', ', $missing_fields) . '. Please update shipping/billing details and retry.';
                $order->update_meta_data('_weave365_order_status', 'failed');
                $order->update_meta_data('_weave365_order_error', sanitize_text_field($err_msg));
                $order->save();
                $order->add_order_note('Weave365 Order Sync Failed: ' . $err_msg);
                return ['success' => false, 'message' => $err_msg];
            }

            // 3. Payment, sender & packing metadata
            $wc_payment_method = (string) $order->get_payment_method();
            $is_cod            = ($wc_payment_method === 'cod');
            $payment_type      = $is_cod ? 'cod' : 'prepaid';
            $gateway_title     = trim((string) $order->get_payment_method_title());
            if ($is_cod) {
                $gateway = $gateway_title !== '' ? $gateway_title : 'cod';
            } else {
                // Prevent a prepaid gateway title containing "cod" substring from triggering backend COD detection
                $gateway = ($gateway_title !== '' && stripos($gateway_title, 'cod') === false)
                    ? $gateway_title
                    : ($wc_payment_method !== '' ? $wc_payment_method : 'prepaid');
            }

            $sender_name = trim((string) get_option(self::OPTION_SENDER_NAME, ''));
            if ($sender_name === '') {
                $sender_name = (string) get_bloginfo('name');
            }
            $sender_phone = trim((string) get_option(self::OPTION_SENDER_PHONE, ''));
            $sender_email = sanitize_email((string) get_option('admin_email', ''));

            $packing_pref = trim((string) get_option(self::OPTION_PACKING_PREFERENCE, self::DEFAULT_PACKING_PREFERENCE));
            if ($packing_pref === '') {
                $packing_pref = self::DEFAULT_PACKING_PREFERENCE;
            }

            $payload = [
                'reseller_order_id'  => (string) $order->get_order_number(),
                'platform'           => 'woocommerce',
                'customer'           => [
                    'name'       => $customer_name,
                    'first_name' => $first_name,
                    'last_name'  => $last_name,
                    'phone'      => $customer_phone,
                    'email'      => $customer_email,
                    'postcode'   => $customer_postcode,
                    'pincode'    => $customer_postcode,
                ],
                'shipping_address'   => [
                    'name'          => $customer_name,
                    'first_name'    => $first_name,
                    'last_name'     => $last_name,
                    'phone'         => $customer_phone,
                    'email'         => $customer_email,
                    'address_line1' => $full_street,
                    'address1'      => $address_1,
                    'address2'      => $address_2,
                    'city'          => $city,
                    'state'         => $state,
                    'postcode'      => $customer_postcode,
                    'pincode'       => $customer_postcode,
                    'country'       => $country,
                ],
                'sender'             => [
                    'name'  => $sender_name,
                    'phone' => $sender_phone,
                    'email' => $sender_email,
                ],
                'items'              => $items,
                'payment_method'     => $wc_payment_method,
                'payment_type'       => $payment_type,
                'gateway'            => $gateway,
                'is_cod'             => $is_cod,
                'shipping_notes'     => trim((string) $order->get_customer_note()),
                'packing_preference' => $packing_pref,
            ];

            $encoded_body = wp_json_encode($payload);
            if ($encoded_body === false) {
                $err_msg = 'Failed to JSON-encode order payload.';
                $order->update_meta_data('_weave365_order_status', 'failed');
                $order->update_meta_data('_weave365_order_error', $err_msg);
                $order->save();
                $order->add_order_note('Weave365 Order Sync Failed: ' . $err_msg);
                return ['success' => false, 'message' => $err_msg];
            }

            // 4. Execute POST /api/v1/orders
            $response = wp_remote_post(self::API_BASE_URL . '/orders', [
                'headers' => [
                    'X-API-Key'    => $api_key,
                    'Content-Type' => 'application/json',
                    'Accept'       => 'application/json',
                    'User-Agent'   => 'Weave365-WooCommerce-Sync/' . self::VERSION,
                ],
                'body'      => $encoded_body,
                'timeout'   => 20,
                'sslverify' => true,
            ]);

            if (is_wp_error($response)) {
                $err_msg = 'Network error communicating with Weave365 API: ' . $response->get_error_message();
                $order->update_meta_data('_weave365_order_status', 'failed');
                $order->update_meta_data('_weave365_order_error', sanitize_text_field($err_msg));
                $order->save();
                $order->add_order_note('Weave365 Order Sync Failed: ' . $err_msg);
                return ['success' => false, 'message' => $err_msg];
            }

            $http_code = (int) wp_remote_retrieve_response_code($response);
            $body_raw  = wp_remote_retrieve_body($response);
            $body      = json_decode($body_raw, true);

            if (json_last_error() !== JSON_ERROR_NONE || !is_array($body)) {
                $err_msg = sprintf('Invalid JSON response from Weave365 API (HTTP %d: %s).', $http_code, json_last_error_msg());
                $order->update_meta_data('_weave365_order_status', 'failed');
                $order->update_meta_data('_weave365_order_error', sanitize_text_field($err_msg));
                $order->save();
                $order->add_order_note('Weave365 Order Sync Failed: ' . $err_msg);
                return ['success' => false, 'message' => $err_msg];
            }

            $resp_code = isset($body['code']) ? (string) $body['code'] : '';
            $api_msg   = !empty($body['message'])
                ? (string) $body['message']
                : (!empty($body['error']) ? (string) $body['error'] : ('HTTP ' . $http_code));

            // Requirement C: Auto-Revocation on 403 FORBIDDEN
            if ($http_code === 403 && $resp_code === 'FORBIDDEN') {
                update_option(self::OPTION_ORDERS_API_ALLOWED, '0', false);
                update_option(self::OPTION_AUTO_FORWARD_ORDERS, '0', false);
                delete_transient(self::TRANSIENT_CAPABILITIES_CHECKED);

                $err_msg = 'Order API access revoked or disabled (HTTP 403 FORBIDDEN): ' . $api_msg . ' Automated order forwarding has been disabled.';
                $order->update_meta_data('_weave365_order_status', 'failed');
                $order->update_meta_data('_weave365_order_error', sanitize_text_field($err_msg));
                $order->save();
                $order->add_order_note('Weave365 Order Sync Revoked: ' . $err_msg);
                return ['success' => false, 'revoked' => true, 'message' => $err_msg];
            }

            // Handle non-2xx responses cleanly
            if ($http_code < 200 || $http_code >= 300) {
                if ($http_code === 409 && !empty($body['unavailable_items']) && is_array($body['unavailable_items'])) {
                    $unavail_skus = [];
                    foreach ($body['unavailable_items'] as $u_item) {
                        if (is_array($u_item) && !empty($u_item['sku'])) {
                            $unavail_skus[] = (string) $u_item['sku'];
                        }
                    }
                    if (!empty($unavail_skus)) {
                        $api_msg .= ' [Out-of-stock SKUs: ' . implode(', ', $unavail_skus) . ']';
                    }
                }

                if ($http_code === 401) {
                    delete_transient(self::TRANSIENT_CAPABILITIES_CHECKED);
                }

                $err_msg = ($resp_code !== '' ? '[' . $resp_code . '] ' : '') . $api_msg . ' (HTTP ' . $http_code . ')';
                $order->update_meta_data('_weave365_order_status', 'failed');
                $order->update_meta_data('_weave365_order_error', sanitize_text_field($err_msg));
                $order->save();
                $order->add_order_note('Weave365 Order Sync Failed: ' . $err_msg);
                return ['success' => false, 'message' => $err_msg];
            }

            // Handle 200 ignored (no Weave365 products in mixed/third-party order)
            if ((isset($body['status']) && $body['status'] === 'ignored') || $resp_code === 'NO_WEAVE365_ITEMS') {
                $order->update_meta_data('_weave365_order_status', 'ignored');
                $order->delete_meta_data('_weave365_order_error');
                $order->save();
                $order->add_order_note('Weave365 Order Sync: Order contains no Weave365 catalog products (NO_WEAVE365_ITEMS). Marked ignored without creating an invoice.');
                return ['success' => true, 'ignored' => true, 'message' => $api_msg];
            }

            // Handle 200 (is_duplicate: true) and 201 (created)
            if (!empty($body['order_id'])) {
                $w365_order_id     = sanitize_text_field((string) $body['order_id']);
                $w365_order_number = (isset($body['order_number']) && $body['order_number'] !== null)
                    ? sanitize_text_field((string) $body['order_number'])
                    : '';
                $payment_link      = !empty($body['payment_link']) ? esc_url_raw((string) $body['payment_link']) : '';
                $is_dup            = !empty($body['is_duplicate']);

                $order->update_meta_data('_weave365_order_id', $w365_order_id);
                $order->update_meta_data('_weave365_order_number', $w365_order_number);
                $order->update_meta_data('_weave365_payment_link', $payment_link);
                $order->update_meta_data('_weave365_order_status', 'sent');
                $order->delete_meta_data('_weave365_order_error');
                $order->save();

                $note_parts = [
                    $is_dup
                        ? 'Weave365 Order Synced (matched existing Weave365 order).'
                        : ($is_manual ? 'Weave365 Order Sent Manually.' : 'Weave365 Order Forwarded Automatically.'),
                    'Weave365 Order ID: ' . esc_html($w365_order_id),
                ];

                if ($w365_order_number !== '') {
                    $note_parts[] = 'Weave365 Order Number: ' . esc_html($w365_order_number);
                }

                if (!empty($body['items_filtered']) && is_array($body['items_filtered'])) {
                    $total_items = isset($body['items_filtered']['total_order_items']) ? (int) $body['items_filtered']['total_order_items'] : 0;
                    $w365_items  = isset($body['items_filtered']['weave365_items_processed']) ? (int) $body['items_filtered']['weave365_items_processed'] : 0;
                    if ($total_items > 0) {
                        $note_parts[] = sprintf('Mixed cart filtered: %d of %d item(s) fulfilled by Weave365.', $w365_items, $total_items);
                    }
                }

                if ($payment_link !== '') {
                    $note_parts[] = 'Wholesale Payment Link: <a href="' . esc_url($payment_link) . '" target="_blank" rel="noopener noreferrer">' . esc_html($payment_link) . '</a>';
                }

                $order->add_order_note(implode(' | ', $note_parts));

                return [
                    'success'      => true,
                    'order_id'     => $w365_order_id,
                    'order_number' => $w365_order_number,
                    'payment_link' => $payment_link,
                    'is_duplicate' => $is_dup,
                ];
            }

            $err_msg = 'Unexpected 2xx response from Weave365 API: missing order_id.';
            $order->update_meta_data('_weave365_order_status', 'failed');
            $order->update_meta_data('_weave365_order_error', $err_msg);
            $order->save();
            $order->add_order_note('Weave365 Order Sync Failed: ' . $err_msg);
            return ['success' => false, 'message' => $err_msg];
        } catch (\Throwable $e) {
            $err_msg = 'Unexpected error during Weave365 order sync: ' . $e->getMessage();
            try {
                $order->update_meta_data('_weave365_order_status', 'failed');
                $order->update_meta_data('_weave365_order_error', sanitize_text_field($err_msg));
                $order->save();
                $order->add_order_note('Weave365 Order Sync Failed: ' . $err_msg);
            } catch (\Throwable $inner) {
                // Prevent fatal exception leakage into checkout/webhooks
            }
            return ['success' => false, 'message' => $err_msg];
        } finally {
            delete_transient($lock_key);
        }
    }

    /**
     * Save stock status / quantity on a WC_Product only when changed, and clear transients.
     *
     * @param \WC_Product $product
     * @param string      $stock_status
     * @param int         $target_qty
     * @return bool True if product was modified and saved.
     */
    private function apply_product_stock_update($product, $stock_status, $target_qty) {
        $needs_save = false;

        if ($product->get_stock_status() !== $stock_status) {
            $product->set_stock_status($stock_status);
            $needs_save = true;
        }

        if ($product->get_manage_stock()) {
            $current_qty = $product->get_stock_quantity();
            if ($current_qty === null || (int) $current_qty !== (int) $target_qty) {
                $product->set_stock_quantity((int) $target_qty);
                $needs_save = true;
            }
        }

        if ($needs_save) {
            $product->save();
            $product_id = $product->get_id();
            wc_delete_product_transients($product_id);
            if ($product->is_type('variation')) {
                $parent_id = $product->get_parent_id();
                if ($parent_id) {
                    wc_delete_product_transients($parent_id);
                }
            }
        }

        return $needs_save;
    }

    public function execute_stock_sync() {
        if (!class_exists('WooCommerce') || !function_exists('wc_get_product_id_by_sku') || !function_exists('wc_get_product')) {
            $msg = 'WooCommerce is not active or required WooCommerce functions are unavailable.';
            update_option(self::OPTION_LAST_SYNC_STATUS, $msg, false);
            return ['success' => false, 'message' => $msg];
        }

        $api_key = trim((string) get_option(self::OPTION_API_KEY, ''));
        if ($api_key === '') {
            $msg = 'API Key is missing. Please save your Live API Key first.';
            update_option(self::OPTION_LAST_SYNC_STATUS, $msg, false);
            return ['success' => false, 'message' => $msg];
        }

        if (get_transient(self::TRANSIENT_LOCK)) {
            return [
                'success' => false,
                'message' => 'Stock sync is already in progress. Please wait for the current sync to complete.'
            ];
        }

        set_transient(self::TRANSIENT_LOCK, time(), 300);

        try {
            $url = self::API_BASE_URL . '/stock-status';
            $response = wp_remote_get($url, [
                'headers' => [
                    'X-API-Key'  => $api_key,
                    'User-Agent' => 'Weave365-WooCommerce-Sync/' . self::VERSION . ' (' . home_url() . ')',
                    'Accept'     => 'application/json',
                ],
                'timeout'   => 30,
                'sslverify' => true,
            ]);

            if (is_wp_error($response)) {
                $err = $response->get_error_message();
                update_option(self::OPTION_LAST_SYNC_STATUS, 'Error: ' . $err, false);
                return ['success' => false, 'message' => $err];
            }

            $code     = wp_remote_retrieve_response_code($response);
            $body_raw = wp_remote_retrieve_body($response);
            $body     = json_decode($body_raw, true);

            if (json_last_error() !== JSON_ERROR_NONE || !is_array($body)) {
                $err = 'Invalid JSON response from Weave365 API (' . json_last_error_msg() . ').';
                update_option(self::OPTION_LAST_SYNC_STATUS, 'API Error: ' . $err, false);
                return ['success' => false, 'message' => $err];
            }

            if ($code !== 200) {
                $err = !empty($body['message']) ? (string) $body['message'] : ('HTTP ' . $code);
                update_option(self::OPTION_LAST_SYNC_STATUS, 'API Error: ' . $err, false);
                return ['success' => false, 'message' => $err];
            }

            if (!isset($body['stock_map']) || !is_array($body['stock_map'])) {
                $msg = 'Stock map was missing or invalid in API response.';
                update_option(self::OPTION_LAST_SYNC_STATUS, $msg, false);
                return ['success' => false, 'message' => $msg];
            }

            if (empty($body['stock_map'])) {
                $msg = 'Stock map in API response is empty.';
                update_option(self::OPTION_LAST_SYNC_TIME, current_time('mysql'), false);
                update_option(self::OPTION_LAST_SYNC_STATUS, $msg, false);
                return ['success' => true, 'message' => $msg, 'updated' => 0];
            }

            $matched_count = 0;
            $updated_count = 0;

            foreach ($body['stock_map'] as $sku => $data) {
                $product_id = wc_get_product_id_by_sku((string) $sku);
                if (!$product_id) {
                    continue;
                }

                $product = wc_get_product($product_id);
                if (!$product) {
                    continue;
                }

                // Skip non-inventory product types (external, grouped, trash)
                if ($product->get_status() === 'trash') {
                    continue;
                }
                $product_type = $product->get_type();
                if (in_array($product_type, ['external', 'grouped'], true)) {
                    continue;
                }

                $matched_count++;

                // Safely parse data payload
                if (is_array($data)) {
                    if (isset($data['is_available'])) {
                        $is_available = !empty($data['is_available']);
                    } elseif (isset($data['in_stock'])) {
                        $is_available = !empty($data['in_stock']);
                    } else {
                        $is_available = false;
                    }
                    $status_str = isset($data['status']) ? strtolower(trim((string) $data['status'])) : ($is_available ? 'in_stock' : 'out_of_stock');
                    $raw_qty    = isset($data['quantity']) && is_numeric($data['quantity']) ? intval($data['quantity']) : 5;
                } elseif (is_bool($data) || is_numeric($data)) {
                    $is_available = is_numeric($data) ? (intval($data) > 0) : !empty($data);
                    $status_str   = $is_available ? 'in_stock' : 'out_of_stock';
                    $raw_qty      = is_numeric($data) ? intval($data) : 5;
                } else {
                    continue;
                }

                // If not available, force quantity to 0 so it doesn't flip back to instock
                $target_qty = $is_available ? max(0, intval($raw_qty)) : 0;

                // Support Variable Products: update child variations gracefully
                if ($product->is_type('variable')) {
                    $children_ids = $product->get_children();
                    if (!empty($children_ids)) {
                        foreach ($children_ids as $child_id) {
                            $child = wc_get_product($child_id);
                            if (!$child || $child->get_status() === 'trash') {
                                continue;
                            }

                            // Skip updating child variation if its own SKU is present in stock_map
                            $child_sku = trim((string) $child->get_sku());
                            if ($child_sku !== '') {
                                if (isset($body['stock_map'][$child_sku]) || array_key_exists($child_sku, $body['stock_map'])) {
                                    continue;
                                }
                                foreach ($body['stock_map'] as $map_k => $map_v) {
                                    if (strcasecmp((string) $map_k, $child_sku) === 0) {
                                        continue 2;
                                    }
                                }
                            }

                            $child_stock_status = $this->resolve_wc_stock_status($child, $status_str, $is_available);
                            if ($this->apply_product_stock_update($child, $child_stock_status, $target_qty)) {
                                $updated_count++;
                            }
                        }
                    }

                    $parent_stock_status = $this->resolve_wc_stock_status($product, $status_str, $is_available);
                    if ($this->apply_product_stock_update($product, $parent_stock_status, $target_qty)) {
                        $updated_count++;
                    }
                } else {
                    $stock_status = $this->resolve_wc_stock_status($product, $status_str, $is_available);
                    if ($this->apply_product_stock_update($product, $stock_status, $target_qty)) {
                        $updated_count++;
                    }
                }
            }

            if ($matched_count === 0) {
                $status_msg = 'Sync completed: 0 matching SKUs found in your WooCommerce store. Please ensure your product or variation SKUs match Weave365 IDs (e.g. 102001 or 102001-1).';
            } else {
                $status_msg = "Successfully synced {$matched_count} matching product(s) ({$updated_count} updated).";
            }

            update_option(self::OPTION_LAST_SYNC_TIME, current_time('mysql'), false);
            update_option(self::OPTION_LAST_SYNC_STATUS, $status_msg, false);

            return [
                'success' => true,
                'message' => $status_msg,
                'matched' => $matched_count,
                'updated' => $updated_count,
            ];
        } finally {
            delete_transient(self::TRANSIENT_LOCK);
        }
    }

    /**
     * Map Weave365 stock status string and availability flag to WooCommerce stock status.
     *
     * @param \WC_Product $product
     * @param string      $status_str
     * @param bool        $is_available
     * @return string
     */
    private function resolve_wc_stock_status($product, $status_str, $is_available) {
        if (in_array($status_str, ['pre-order', 'back-soon', 'onbackorder'], true)) {
            if (method_exists($product, 'backorders_allowed') && $product->backorders_allowed()) {
                return 'onbackorder';
            }
            return $is_available ? 'instock' : 'outofstock';
        }
        return $is_available ? 'instock' : 'outofstock';
    }

    /**
     * Store API Cart Errors Hook (WooCommerce Blocks 8.3+)
     *
     * @param \WP_Error $errors Store API error collection
     * @param \WC_Cart  $cart   Cart instance
     */
    public function validate_store_api_cart_stock($errors, $cart = null) {
        $stock_errors = $this->check_cart_stock_errors(false);
        if (!empty($stock_errors) && is_wp_error($errors)) {
            foreach ($stock_errors as $message) {
                $errors->add('out_of_stock', $message);
            }
        }
    }

    /**
     * Store API Checkout Submission Hook (WooCommerce Blocks 8.3+)
     *
     * Forces live stock validation during block checkout submission.
     * Throws RouteException if any item is out of stock or exceeds available quantity.
     *
     * @param \WC_Order        $order   Order instance being created
     * @param \WP_REST_Request $request REST request object
     * @throws \Automattic\WooCommerce\StoreApi\Exceptions\RouteException|\Exception
     */
    public function validate_store_api_checkout_stock($order = null, $request = null) {
        $stock_errors = $this->check_cart_stock_errors(true);
        if (!empty($stock_errors)) {
            $first_error = reset($stock_errors);
            if (class_exists('\Automattic\WooCommerce\StoreApi\Exceptions\RouteException')) {
                throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException(
                    'out_of_stock',
                    $first_error,
                    400
                );
            } else {
                throw new \Exception($first_error);
            }
        }
    }

    /**
     * Mandatory Real-Time Pre-Checkout Stock Verification Guard (Classic Checkout).
     *
     * Validates loom availability via /api/v1/stock-status?skus=... before order placement.
     * Caches casual cart views for 45 seconds; forces live check during checkout submission.
     *
     * @param bool|null $force_live Explicitly override live check or auto-detect checkout submission.
     */
    public function validate_cart_stock_live($force_live = null) {
        if ($force_live === null) {
            $force_live = doing_action('woocommerce_checkout_process')
                || (defined('DOING_AJAX') && DOING_AJAX && isset($_GET['wc-ajax']) && $_GET['wc-ajax'] === 'checkout')
                || isset($_POST['woocommerce_checkout_place_order']);
        }

        $stock_errors = $this->check_cart_stock_errors((bool) $force_live);
        if (!empty($stock_errors)) {
            foreach ($stock_errors as $msg) {
                $escaped_msg = esc_html($msg);
                if (function_exists('wc_has_notice') && wc_has_notice($escaped_msg, 'error')) {
                    continue;
                }
                wc_add_notice($escaped_msg, 'error');
            }
        }
    }

    /**
     * Core Cart & Checkout Stock Verification Engine.
     *
     * 1. Extracts unique SKUs and sums cart quantities.
     * 2. Deduplicates multiple cart lines sharing the same SKU.
     * 3. Implements 45-second transient caching on casual cart-browse (keyed by sorted unique SKUs only),
     *    always bypassing cache on checkout submission.
     * 4. Updates product stock status and quantity only when changed, once per unique SKU.
     * 5. Clears product transients and parent transients for variations.
     * 6. Returns plain customer-facing error strings.
     *
     * @param bool $force_live If true, bypasses 45s transient cache and queries API live.
     * @return array Array of customer-facing error messages.
     */
    public function check_cart_stock_errors($force_live = false) {
        if (!function_exists('WC') || !WC()->cart || WC()->cart->is_empty()) {
            return [];
        }

        $api_key = trim((string) get_option(self::OPTION_API_KEY, ''));
        if ($api_key === '') {
            return [];
        }

        $cart_items = WC()->cart->get_cart();
        if (empty($cart_items)) {
            return [];
        }

        $sku_quantities = [];
        $sku_products   = [];

        foreach ($cart_items as $cart_item_key => $cart_item) {
            if (empty($cart_item['data']) || !is_a($cart_item['data'], 'WC_Product')) {
                continue;
            }

            /** @var WC_Product $product */
            $product = $cart_item['data'];
            $sku     = trim((string) $product->get_sku());

            // If variation has no SKU, fallback to parent product SKU
            if ($sku === '' && $product->is_type('variation')) {
                $parent_id = $product->get_parent_id();
                if ($parent_id) {
                    $parent = wc_get_product($parent_id);
                    if ($parent) {
                        $sku = trim((string) $parent->get_sku());
                    }
                }
            }

            if ($sku === '') {
                continue;
            }

            $qty = isset($cart_item['quantity']) ? max(1, (int) $cart_item['quantity']) : 1;
            $sku_quantities[$sku] = ($sku_quantities[$sku] ?? 0) + $qty;

            // De-duplicate: Keep only the first WC_Product object per unique SKU
            if (!isset($sku_products[$sku])) {
                $sku_products[$sku] = $product;
            }
        }

        if (empty($sku_quantities)) {
            return [];
        }

        // De-duplicate checks within the same HTTP request lifecycle
        static $checked_results = [];
        $cart_fingerprint = md5(wp_json_encode($sku_quantities));
        $execution_key    = $cart_fingerprint . ($force_live ? '_live' : '_browse');
        if (isset($checked_results[$execution_key])) {
            return $checked_results[$execution_key];
        }

        // Build 45-second transient cache key from sorted unique SKUs only
        $unique_skus = array_map('strval', array_keys($sku_quantities));
        sort($unique_skus, SORT_STRING);
        $transient_key = 'w365_stock_' . md5($api_key . '_' . implode(',', $unique_skus));

        $stock_map = null;

        // Use cache if browsing; always bypass cache on checkout submission
        if (!$force_live) {
            $cached = get_transient($transient_key);
            if (is_array($cached)) {
                $stock_map = $cached;
            }
        }

        if ($stock_map === null) {
            $skus_param = implode(',', $unique_skus);
            $url        = self::API_BASE_URL . '/stock-status?skus=' . rawurlencode($skus_param);

            $response = wp_remote_get($url, [
                'headers' => [
                    'X-API-Key'  => $api_key,
                    'User-Agent' => 'Weave365-WooCommerce-Sync/' . self::VERSION . '-checkout (' . home_url() . ')',
                    'Accept'     => 'application/json',
                ],
                'timeout'   => 4, // Fast 4-second timeout to avoid checkout lag
                'sslverify' => true,
            ]);

            if (is_wp_error($response)) {
                // Fail open gracefully so temporary network hiccups don't block store sales
                $checked_results[$execution_key] = [];
                return [];
            }

            $code = wp_remote_retrieve_response_code($response);
            if ($code !== 200) {
                $checked_results[$execution_key] = [];
                return [];
            }

            $body = json_decode(wp_remote_retrieve_body($response), true);
            if (json_last_error() !== JSON_ERROR_NONE || !is_array($body) || !isset($body['stock_map']) || !is_array($body['stock_map'])) {
                $checked_results[$execution_key] = [];
                return [];
            }

            $stock_map = $body['stock_map'];

            // Cache stock status for 45 seconds to protect reseller API quota
            set_transient($transient_key, $stock_map, 45);
        }

        $errors = [];

        foreach ($sku_quantities as $sku => $cart_qty) {
            $matched_data = null;

            if (isset($stock_map[$sku])) {
                $matched_data = $stock_map[$sku];
            } else {
                foreach ($stock_map as $map_sku => $val) {
                    if (strcasecmp((string) $map_sku, (string) $sku) === 0) {
                        $matched_data = $val;
                        break;
                    }
                }
            }

            // If not found in Weave365 stock map, assume it is third-party/non-Weave365 stock
            if ($matched_data === null) {
                continue;
            }

            $is_available  = false;
            $available_qty = 0;

            if (is_array($matched_data)) {
                if (isset($matched_data['is_available'])) {
                    $is_available = !empty($matched_data['is_available']);
                } elseif (isset($matched_data['in_stock'])) {
                    $is_available = !empty($matched_data['in_stock']);
                }
                $available_qty = isset($matched_data['quantity']) && is_numeric($matched_data['quantity'])
                    ? max(0, intval($matched_data['quantity']))
                    : ($is_available ? 5 : 0);
            } elseif (is_bool($matched_data) || is_numeric($matched_data)) {
                $is_available  = is_numeric($matched_data) ? (intval($matched_data) > 0) : !empty($matched_data);
                $available_qty = is_numeric($matched_data) ? max(0, intval($matched_data)) : ($is_available ? 5 : 0);
            }

            /** @var WC_Product $product */
            $product      = $sku_products[$sku];
            $product_name = $product->get_name();

            // Case 1: Out of stock
            if (!$is_available || $available_qty <= 0) {
                $this->apply_product_stock_update($product, 'outofstock', 0);

                /* translators: %s: product name */
                $errors[] = sprintf(
                    __('Sorry, "%s" is currently out of stock and cannot be ordered.', 'weave365'),
                    $product_name
                );
                continue;
            }

            // Case 2: Customer ordered more than available
            if ($cart_qty > $available_qty) {
                $target_status = $product->get_stock_status() === 'outofstock' ? 'instock' : $product->get_stock_status();
                $this->apply_product_stock_update($product, $target_status, $available_qty);

                /* translators: 1: product name, 2: available count, 3: requested count */
                $errors[] = sprintf(
                    __('Sorry, "%1$s" only has %2$d item(s) available in stock (you requested %3$d). Please update your cart to proceed.', 'weave365'),
                    $product_name,
                    $available_qty,
                    $cart_qty
                );
            }
        }

        $checked_results[$execution_key] = $errors;
        return $errors;
    }
}

// Lifecycle hooks
register_activation_hook(__FILE__, ['Weave365_WooCommerce_Sync', 'plugin_activated']);
register_deactivation_hook(__FILE__, ['Weave365_WooCommerce_Sync', 'plugin_deactivated']);

// Guard WooCommerce dependency on plugins_loaded
add_action('plugins_loaded', function () {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', ['Weave365_WooCommerce_Sync', 'woocommerce_missing_notice']);
        return;
    }

    new Weave365_WooCommerce_Sync();
});
