<?php
/**
 * Weave365 Live Stock & Order Sync for WooCommerce - Uninstall Script
 *
 * Cleans up all options, transients, and scheduled events when the plugin is
 * uninstalled via WordPress Admin.
 *
 * @package Weave365_WooCommerce_Sync
 */

// If uninstall not called from WordPress, exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Delete all plugin options
$weave365_options = [
    'weave365_api_key',
    'weave365_last_sync_time',
    'weave365_last_sync_status',
    'weave365_orders_api_allowed',
    'weave365_account_tier',
    'weave365_client_name',
    'weave365_remaining_quota',
    'weave365_auto_forward_orders',
    'weave365_forward_cod_orders',
    'weave365_sender_name',
    'weave365_sender_phone',
    'weave365_packing_preference',
];

foreach ($weave365_options as $weave365_option) {
    delete_option($weave365_option);
}

// Delete named transients
delete_transient('weave365_sync_lock');
delete_transient('weave365_capabilities_checked');

// Clean up any dynamic cart stock cache or per-order lock transients
global $wpdb;
if (isset($wpdb) && is_object($wpdb) && !empty($wpdb->options) && method_exists($wpdb, 'query') && method_exists($wpdb, 'prepare')) {
    $wpdb->query(
        $wpdb->prepare(
            "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
            $wpdb->esc_like('_transient_w365_') . '%',
            $wpdb->esc_like('_transient_timeout_w365_') . '%'
        )
    );
}

// Clear any remaining scheduled cron events
wp_clear_scheduled_hook('weave365_cron_stock_sync');
